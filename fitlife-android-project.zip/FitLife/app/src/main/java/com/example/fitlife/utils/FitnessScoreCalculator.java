package com.example.fitlife.utils;

public class FitnessScoreCalculator {

    public static class ScoreResult {
        public int score; // 0 - 100
        public String category; // Excellent, Good, Needs Improvement, Let's Get Started
        public String message;

        public ScoreResult(int score, String category, String message) {
            this.score = score;
            this.category = category;
            this.message = message;
        }
    }

    /**
     * Calculates dynamic composite fitness score from 0-100:
     * - Steps (up to 30 pts based on 10,000 steps)
     * - Calories (up to 25 pts based on 600 kcal)
     * - Workout Duration (up to 20 pts based on 30 mins)
     * - Water intake (up to 15 pts based on 8 glasses)
     * - Sleep (up to 10 pts based on 7-8 hours)
     */
    public static ScoreResult calculateScore(int steps, int stepGoal,
                                            int caloriesBurned, int calorieGoal,
                                            int activeMins, int activeMinsGoal,
                                            int waterGlasses, int waterGoal,
                                            double sleepHours) {
        double stepPts = Math.min(30.0, (steps / (double) Math.max(1, stepGoal)) * 30.0);
        double calPts = Math.min(25.0, (caloriesBurned / (double) Math.max(1, calorieGoal)) * 25.0);
        double workoutPts = Math.min(20.0, (activeMins / (double) Math.max(1, activeMinsGoal)) * 20.0);
        double waterPts = Math.min(15.0, (waterGlasses / (double) Math.max(1, waterGoal)) * 15.0);

        double sleepPts = 0.0;
        if (sleepHours >= 7.0 && sleepHours <= 9.0) {
            sleepPts = 10.0;
        } else if (sleepHours >= 6.0) {
            sleepPts = 7.0;
        } else if (sleepHours >= 5.0) {
            sleepPts = 4.0;
        }

        int total = (int) Math.round(stepPts + calPts + workoutPts + waterPts + sleepPts);
        total = Math.max(0, Math.min(100, total));

        String category;
        String message;

        if (total >= 80) {
            category = "Excellent 🔥";
            message = "Outstanding consistency! Your movement, hydration, and recovery are aligned for peak wellness.";
        } else if (total >= 60) {
            category = "Good 👍";
            message = "Solid performance! You are maintaining strong habits. A little more movement or water will push you into Excellent.";
        } else if (total >= 40) {
            category = "Needs Improvement 💪";
            message = "You have made progress, but there is room to grow! Try a 15-minute walk and hydrate regularly today.";
        } else {
            category = "Let's Get Started 🚀";
            message = "Every fitness journey begins with one step! Put on your sneakers, drink a glass of water, and start moving.";
        }

        return new ScoreResult(total, category, message);
    }
}
