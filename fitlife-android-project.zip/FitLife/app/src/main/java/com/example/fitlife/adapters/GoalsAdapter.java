package com.example.fitlife.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fitlife.R;
import com.example.fitlife.models.Goal;

import java.util.ArrayList;
import java.util.List;

public class GoalsAdapter extends RecyclerView.Adapter<GoalsAdapter.GoalViewHolder> {

    public interface OnGoalActionListener {
        void onEdit(Goal goal);
        void onDelete(Goal goal);
    }

    private List<Goal> goalList = new ArrayList<>();
    private final OnGoalActionListener listener;

    public GoalsAdapter(OnGoalActionListener listener) {
        this.listener = listener;
    }

    public void setGoals(List<Goal> goals) {
        this.goalList = goals != null ? goals : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public GoalViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_goal, parent, false);
        return new GoalViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GoalViewHolder holder, int position) {
        Goal goal = goalList.get(position);
        holder.bind(goal, listener);
    }

    @Override
    public int getItemCount() {
        return goalList.size();
    }

    static class GoalViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvProgress, tvPercentage;
        ProgressBar progressBar;
        View btnDelete;

        public GoalViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvGoalTitle);
            tvProgress = itemView.findViewById(R.id.tvGoalProgress);
            tvPercentage = itemView.findViewById(R.id.tvGoalPercentage);
            progressBar = itemView.findViewById(R.id.progressBarGoal);
            btnDelete = itemView.findViewById(R.id.btnDeleteGoal);
        }

        public void bind(Goal goal, OnGoalActionListener listener) {
            tvTitle.setText(goal.getTitle());
            String progressText = String.format(java.util.Locale.getDefault(), "%.0f / %.0f %s",
                    goal.getCurrentProgress(), goal.getTarget(), goal.getUnit());
            tvProgress.setText(progressText);

            int pct = goal.getPercentage();
            tvPercentage.setText(pct + "%");
            progressBar.setProgress(pct);

            if (btnDelete != null) {
                btnDelete.setOnClickListener(v -> {
                    if (listener != null) listener.onDelete(goal);
                });
            }

            itemView.setOnClickListener(v -> {
                if (listener != null) listener.onEdit(goal);
            });
        }
    }
}
