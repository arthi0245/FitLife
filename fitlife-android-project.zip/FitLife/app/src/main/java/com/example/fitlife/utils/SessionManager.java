package com.example.fitlife.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "FitLifeSession";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_USER_EMAIL = "userEmail";

    private static final String KEY_STEP_GOAL = "stepGoal";
    private static final String KEY_CALORIE_GOAL = "calorieGoal";
    private static final String KEY_WATER_GOAL = "waterGoal";
    private static final String KEY_DARK_MODE = "darkMode";
    private static final String KEY_DEMO_SENSOR_MODE = "demoSensorMode";

    private final SharedPreferences pref;
    private final SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void setLogin(boolean isLoggedIn, String userId, String name, String email) {
        editor.putBoolean(KEY_IS_LOGGED_IN, isLoggedIn);
        editor.putString(KEY_USER_ID, userId);
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public String getUserId() {
        return pref.getString(KEY_USER_ID, "");
    }

    public String getUserName() {
        return pref.getString(KEY_USER_NAME, "Athlete");
    }

    public String getUserEmail() {
        return pref.getString(KEY_USER_EMAIL, "");
    }

    public int getStepGoal() {
        return pref.getInt(KEY_STEP_GOAL, 10000);
    }

    public void setStepGoal(int goal) {
        editor.putInt(KEY_STEP_GOAL, goal).apply();
    }

    public int getCalorieGoal() {
        return pref.getInt(KEY_CALORIE_GOAL, 600);
    }

    public void setCalorieGoal(int goal) {
        editor.putInt(KEY_CALORIE_GOAL, goal).apply();
    }

    public int getWaterGoal() {
        return pref.getInt(KEY_WATER_GOAL, 8);
    }

    public void setWaterGoal(int goal) {
        editor.putInt(KEY_WATER_GOAL, goal).apply();
    }

    public boolean isDarkMode() {
        return pref.getBoolean(KEY_DARK_MODE, false);
    }

    public void setDarkMode(boolean enabled) {
        editor.putBoolean(KEY_DARK_MODE, enabled).apply();
    }

    public boolean isDemoSensorMode() {
        return pref.getBoolean(KEY_DEMO_SENSOR_MODE, false);
    }

    public void setDemoSensorMode(boolean enabled) {
        editor.putBoolean(KEY_DEMO_SENSOR_MODE, enabled).apply();
    }

    public void logout() {
        editor.clear();
        editor.apply();
    }
}
