package com.example.fitlife.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fitlife.R;
import com.example.fitlife.adapters.WorkoutAdapter;
import com.example.fitlife.firebase.FirebaseHelper;
import com.example.fitlife.models.ActivityLog;
import com.example.fitlife.models.Workout;
import com.example.fitlife.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WorkoutActivity extends AppCompatActivity implements WorkoutAdapter.OnWorkoutClickListener {

    private RecyclerView rvWorkouts;
    private WorkoutAdapter adapter;
    private CardView cardActiveWorkout;
    private TextView tvActiveWorkoutName, tvActiveWorkoutTimer, tvActiveWorkoutCals;
    private Button btnPauseWorkout, btnResumeWorkout, btnCompleteWorkout;

    private Handler timerHandler = new Handler(Looper.getMainLooper());
    private boolean isTimerRunning = false;
    private boolean isTimerPaused = false;
    private long secondsElapsed = 0;
    private Workout currentWorkout;

    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (isTimerRunning && !isTimerPaused) {
                secondsElapsed++;
                long mins = secondsElapsed / 60;
                long secs = secondsElapsed % 60;
                tvActiveWorkoutTimer.setText(String.format(Locale.getDefault(), "%02d:%02d", mins, secs));

                if (currentWorkout != null && currentWorkout.getDurationMinutes() > 0) {
                    double calsPerSec = currentWorkout.getEstimatedCalories() / (double) (currentWorkout.getDurationMinutes() * 60);
                    int liveCals = (int) Math.round(secondsElapsed * calsPerSec);
                    tvActiveWorkoutCals.setText(liveCals + " kcal burned");
                }
                timerHandler.postDelayed(this, 1000);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);

        initViews();
        setupList();
    }

    private void initViews() {
        rvWorkouts = findViewById(R.id.rvWorkouts);
        cardActiveWorkout = findViewById(R.id.cardActiveWorkout);
        tvActiveWorkoutName = findViewById(R.id.tvActiveWorkoutName);
        tvActiveWorkoutTimer = findViewById(R.id.tvActiveWorkoutTimer);
        tvActiveWorkoutCals = findViewById(R.id.tvActiveWorkoutCals);

        btnPauseWorkout = findViewById(R.id.btnPauseWorkout);
        btnResumeWorkout = findViewById(R.id.btnResumeWorkout);
        btnCompleteWorkout = findViewById(R.id.btnCompleteWorkout);

        findViewById(R.id.btnBackWorkout).setOnClickListener(v -> finish());

        btnPauseWorkout.setOnClickListener(v -> {
            isTimerPaused = true;
            btnPauseWorkout.setVisibility(View.GONE);
            btnResumeWorkout.setVisibility(View.VISIBLE);
        });

        btnResumeWorkout.setOnClickListener(v -> {
            isTimerPaused = false;
            btnPauseWorkout.setVisibility(View.VISIBLE);
            btnResumeWorkout.setVisibility(View.GONE);
            timerHandler.post(runnable);
        });

        btnCompleteWorkout.setOnClickListener(v -> finishWorkoutSession());
    }

    private void setupList() {
        rvWorkouts.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WorkoutAdapter(this);
        rvWorkouts.setAdapter(adapter);

        List<Workout> list = new ArrayList<>();
        list.add(new Workout("w1", "High Intensity Full Body Circuit", "HIIT", 20, 220, "Advanced",
                "Burpees, jump squats, high knees, and mountain climbers designed for maximal metabolic burn."));
        list.add(new Workout("w2", "Upper Body Power Sculpt", "Strength Training", 30, 240, "Intermediate",
                "Push-ups, dumbbell shoulder presses, dips, and core planks to tone and build upper body strength."));
        list.add(new Workout("w3", "Brisk Morning Cardio Blast", "Cardio", 25, 200, "Beginner",
                "Low-impact interval cardio to kickstart circulation, elevate heart rate, and burn calories."));
        list.add(new Workout("w4", "Deep Restorative Flow", "Yoga", 20, 110, "All Levels",
                "Sun salutations, warrior poses, and spinal twists for full-body flexibility and mental decompression."));
        list.add(new Workout("w5", "Full-Body Mobility & Cool Down", "Stretching", 15, 75, "Beginner",
                "Hamstring stretches, hip openers, and shoulder rolls to prevent injury and promote quick recovery."));

        adapter.setWorkouts(list);
    }

    @Override
    public void onStartWorkout(Workout workout) {
        currentWorkout = workout;
        cardActiveWorkout.setVisibility(View.VISIBLE);
        tvActiveWorkoutName.setText(workout.getName());
        secondsElapsed = 0;
        isTimerRunning = true;
        isTimerPaused = false;

        btnPauseWorkout.setVisibility(View.VISIBLE);
        btnResumeWorkout.setVisibility(View.GONE);

        timerHandler.removeCallbacks(runnable);
        timerHandler.post(runnable);

        Toast.makeText(this, "Started " + workout.getName() + "!", Toast.LENGTH_SHORT).show();
    }

    private void finishWorkoutSession() {
        isTimerRunning = false;
        timerHandler.removeCallbacks(runnable);

        int burned = 50;
        if (currentWorkout != null && currentWorkout.getDurationMinutes() > 0) {
            double calsPerSec = currentWorkout.getEstimatedCalories() / (double) (currentWorkout.getDurationMinutes() * 60);
            burned = Math.max(20, (int) Math.round(secondsElapsed * calsPerSec));
        }

        SessionManager session = new SessionManager(this);
        String uid = session.getUserId();
        String today = FirebaseHelper.getInstance().getTodayDateString();

        ActivityLog log = new ActivityLog(
                null, uid, "Workout: " + (currentWorkout != null ? currentWorkout.getName() : "General"),
                System.currentTimeMillis() - (secondsElapsed * 1000), System.currentTimeMillis(),
                secondsElapsed, 0, 0.0, burned, today
        );

        FirebaseHelper.getInstance().logActivity(uid, log, task -> {
            Toast.makeText(this, "🎉 Workout Completed! You burned " + burned + " kcal!", Toast.LENGTH_LONG).show();
            cardActiveWorkout.setVisibility(View.GONE);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timerHandler.removeCallbacks(runnable);
    }
}
