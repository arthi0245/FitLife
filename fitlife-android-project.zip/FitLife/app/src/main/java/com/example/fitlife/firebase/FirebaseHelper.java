package com.example.fitlife.firebase;

import com.example.fitlife.models.ActivityLog;
import com.example.fitlife.models.Goal;
import com.example.fitlife.models.HealthData;
import com.example.fitlife.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class FirebaseHelper {
    private static FirebaseHelper instance;
    private final FirebaseAuth auth;
    private final FirebaseDatabase database;
    private final DatabaseReference usersRef;

    private FirebaseHelper() {
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        // Enable offline persistence if required
        try {
            database.setPersistenceEnabled(true);
        } catch (Exception ignored) {}
        usersRef = database.getReference("Users");
    }

    public static synchronized FirebaseHelper getInstance() {
        if (instance == null) {
            instance = new FirebaseHelper();
        }
        return instance;
    }

    public FirebaseAuth getAuth() { return auth; }
    public FirebaseUser getCurrentUser() { return auth.getCurrentUser(); }

    public String getCurrentUserId() {
        FirebaseUser user = auth.getCurrentUser();
        return user != null ? user.getUid() : "guest_user";
    }

    public DatabaseReference getUserRootRef(String userId) {
        return usersRef.child(userId);
    }

    public void saveUserProfile(User user, OnCompleteListener<Void> listener) {
        String uid = user.getUserId() != null ? user.getUserId() : getCurrentUserId();
        usersRef.child(uid).child("Profile").setValue(user).addOnCompleteListener(listener);
    }

    public void getUserProfile(String userId, ValueEventListener listener) {
        usersRef.child(userId).child("Profile").addValueEventListener(listener);
    }

    public String getTodayDateString() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    public void syncDailySteps(String userId, int steps, int calories, double distanceKm) {
        String today = getTodayDateString();
        DatabaseReference dayRef = usersRef.child(userId).child("DailyActivity").child(today);

        Map<String, Object> updates = new HashMap<>();
        updates.put("steps", steps);
        updates.put("caloriesBurned", calories);
        updates.put("distanceKm", distanceKm);
        updates.put("lastUpdated", System.currentTimeMillis());

        dayRef.updateChildren(updates);
    }

    public void logActivity(String userId, ActivityLog activity, OnCompleteListener<Void> listener) {
        String activityId = usersRef.child(userId).child("Activities").push().getKey();
        if (activityId != null) {
            activity.setId(activityId);
            usersRef.child(userId).child("Activities").child(activityId).setValue(activity).addOnCompleteListener(listener);
        }
    }

    public void saveGoal(String userId, Goal goal, OnCompleteListener<Void> listener) {
        if (goal.getId() == null || goal.getId().isEmpty()) {
            String goalId = usersRef.child(userId).child("Goals").push().getKey();
            goal.setId(goalId);
        }
        usersRef.child(userId).child("Goals").child(goal.getId()).setValue(goal).addOnCompleteListener(listener);
    }

    public void deleteGoal(String userId, String goalId, OnCompleteListener<Void> listener) {
        usersRef.child(userId).child("Goals").child(goalId).removeValue().addOnCompleteListener(listener);
    }

    public void syncHealthData(String userId, HealthData data, OnCompleteListener<Void> listener) {
        String today = data.getDate() != null ? data.getDate() : getTodayDateString();
        usersRef.child(userId).child("HealthData").child(today).setValue(data).addOnCompleteListener(listener);
    }

    public void attachTodayActivityListener(String userId, ValueEventListener listener) {
        String today = getTodayDateString();
        usersRef.child(userId).child("DailyActivity").child(today).addValueEventListener(listener);
    }

    public void attachGoalsListener(String userId, ValueEventListener listener) {
        usersRef.child(userId).child("Goals").addValueEventListener(listener);
    }
}
