package com.example.fitlife.models;

import java.io.Serializable;

public class FoodItem implements Serializable {
    private String id;
    private String name;
    private String mealType; // BREAKFAST, LUNCH, EVENING, DINNER, HEALTHY_SNACKS
    private int calories;
    private int proteinGrams;
    private int carbsGrams;
    private String servingSize;
    private String healthBenefits;
    private String recommendedFor; // Weight Loss, Muscle Gain, General Wellness
    private boolean eaten;

    public FoodItem() {}

    public FoodItem(String id, String name, String mealType, int calories, int proteinGrams,
                    int carbsGrams, String servingSize, String healthBenefits, String recommendedFor) {
        this.id = id;
        this.name = name;
        this.mealType = mealType;
        this.calories = calories;
        this.proteinGrams = proteinGrams;
        this.carbsGrams = carbsGrams;
        this.servingSize = servingSize;
        this.healthBenefits = healthBenefits;
        this.recommendedFor = recommendedFor;
        this.eaten = false;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getMealType() { return mealType; }
    public void setMealType(String mealType) { this.mealType = mealType; }

    public int getCalories() { return calories; }
    public void setCalories(int calories) { this.calories = calories; }

    public int getProteinGrams() { return proteinGrams; }
    public void setProteinGrams(int proteinGrams) { this.proteinGrams = proteinGrams; }

    public int getCarbsGrams() { return carbsGrams; }
    public void setCarbsGrams(int carbsGrams) { this.carbsGrams = carbsGrams; }

    public String getServingSize() { return servingSize; }
    public void setServingSize(String servingSize) { this.servingSize = servingSize; }

    public String getHealthBenefits() { return healthBenefits; }
    public void setHealthBenefits(String healthBenefits) { this.healthBenefits = healthBenefits; }

    public String getRecommendedFor() { return recommendedFor; }
    public void setRecommendedFor(String recommendedFor) { this.recommendedFor = recommendedFor; }

    public boolean isEaten() { return eaten; }
    public void setEaten(boolean eaten) { this.eaten = eaten; }
}
