package com.example.fitlife.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fitlife.R;
import com.example.fitlife.firebase.FirebaseHelper;
import com.example.fitlife.models.ActivityLog;
import com.example.fitlife.utils.SessionManager;

import java.util.Locale;

public class ActivityTrackerActivity extends AppCompatActivity {

    private TextView tvTimer, tvActivitySteps, tvActivityCalories, tvActivityDistance, tvActivityState;
    private RadioGroup rgActivityType;
    private Button btnStart, btnPause, btnResume, btnStopSave;

    private Handler timerHandler = new Handler(Looper.getMainLooper());
    private boolean isRunning = false;
    private boolean isPaused = false;
    private long secondsElapsed = 0;
    private long startTime = 0;

    private int activeSteps = 0;
    private double activeDistanceKm = 0.0;
    private int activeCalories = 0;
    private String selectedType = "Walking";

    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (isRunning && !isPaused) {
                secondsElapsed++;

                // Dynamic simulation calculations per second based on activity type
                double speedMultiplier = 1.0;
                double calPerSec = 0.08;
                if ("Running".equals(selectedType)) {
                    speedMultiplier = 2.4;
                    calPerSec = 0.19;
                } else if ("Cycling".equals(selectedType)) {
                    speedMultiplier = 3.2;
                    calPerSec = 0.15;
                } else if ("Workout".equals(selectedType)) {
                    speedMultiplier = 0.5;
                    calPerSec = 0.16;
                }

                if (!"Cycling".equals(selectedType)) {
                    activeSteps += (int) (1.8 * speedMultiplier);
                }
                activeDistanceKm += (0.0014 * speedMultiplier);
                activeCalories = (int) Math.round(secondsElapsed * calPerSec);

                updateUI();
                timerHandler.postDelayed(this, 1000);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);

        initViews();
        setupListeners();
        updateUI();
    }

    private void initViews() {
        tvTimer = findViewById(R.id.tvTimer);
        tvActivitySteps = findViewById(R.id.tvActivitySteps);
        tvActivityCalories = findViewById(R.id.tvActivityCalories);
        tvActivityDistance = findViewById(R.id.tvActivityDistance);
        tvActivityState = findViewById(R.id.tvActivityState);
        rgActivityType = findViewById(R.id.rgActivityType);

        btnStart = findViewById(R.id.btnStartActivity);
        btnPause = findViewById(R.id.btnPauseActivity);
        btnResume = findViewById(R.id.btnResumeActivity);
        btnStopSave = findViewById(R.id.btnStopSaveActivity);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    private void setupListeners() {
        rgActivityType.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbWalking) selectedType = "Walking";
            else if (checkedId == R.id.rbRunning) selectedType = "Running";
            else if (checkedId == R.id.rbCycling) selectedType = "Cycling";
            else if (checkedId == R.id.rbWorkout) selectedType = "Workout";
        });

        btnStart.setOnClickListener(v -> startActivityTracking());
        btnPause.setOnClickListener(v -> pauseActivityTracking());
        btnResume.setOnClickListener(v -> resumeActivityTracking());
        btnStopSave.setOnClickListener(v -> stopAndSaveActivity());
    }

    private void startActivityTracking() {
        isRunning = true;
        isPaused = false;
        secondsElapsed = 0;
        activeSteps = 0;
        activeDistanceKm = 0.0;
        activeCalories = 0;
        startTime = System.currentTimeMillis();

        tvActivityState.setText("● Active • Tracking in Real-Time");
        btnStart.setVisibility(View.GONE);
        btnPause.setVisibility(View.VISIBLE);
        btnResume.setVisibility(View.GONE);
        btnStopSave.setVisibility(View.VISIBLE);

        for (int i = 0; i < rgActivityType.getChildCount(); i++) {
            rgActivityType.getChildAt(i).setEnabled(false);
        }

        timerHandler.post(timerRunnable);
    }

    private void pauseActivityTracking() {
        isPaused = true;
        tvActivityState.setText("❚❚ Paused");
        btnPause.setVisibility(View.GONE);
        btnResume.setVisibility(View.VISIBLE);
    }

    private void resumeActivityTracking() {
        isPaused = false;
        tvActivityState.setText("● Active • Tracking in Real-Time");
        btnPause.setVisibility(View.VISIBLE);
        btnResume.setVisibility(View.GONE);
        timerHandler.post(timerRunnable);
    }

    private void stopAndSaveActivity() {
        isRunning = false;
        isPaused = false;
        timerHandler.removeCallbacks(timerRunnable);
        long endTime = System.currentTimeMillis();

        SessionManager session = new SessionManager(this);
        String uid = session.getUserId();
        String today = FirebaseHelper.getInstance().getTodayDateString();

        ActivityLog log = new ActivityLog(
                null, uid, selectedType, startTime, endTime,
                secondsElapsed, activeSteps,
                Math.round(activeDistanceKm * 100.0) / 100.0,
                activeCalories, today
        );

        FirebaseHelper.getInstance().logActivity(uid, log, task -> {
            Toast.makeText(this, selectedType + " activity saved to Firebase!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void updateUI() {
        long mins = secondsElapsed / 60;
        long secs = secondsElapsed % 60;
        tvTimer.setText(String.format(Locale.getDefault(), "%02d:%02d", mins, secs));
        tvActivitySteps.setText(String.format(Locale.getDefault(), "%,d", activeSteps));
        tvActivityCalories.setText(activeCalories + " kcal");
        tvActivityDistance.setText(String.format(Locale.getDefault(), "%.2f km", activeDistanceKm));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timerHandler.removeCallbacks(timerRunnable);
    }
}
