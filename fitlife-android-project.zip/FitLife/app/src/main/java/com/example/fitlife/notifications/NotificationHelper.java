package com.example.fitlife.notifications;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.fitlife.R;
import com.example.fitlife.activities.MainActivity;

public class NotificationHelper {
    public static final String CHANNEL_REMINDERS = "fitlife_reminders";
    public static final String CHANNEL_MILESTONES = "fitlife_milestones";

    public static void createNotificationChannels(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager == null) return;

            NotificationChannel reminderChannel = new NotificationChannel(
                    CHANNEL_REMINDERS,
                    "Health Reminders",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            reminderChannel.setDescription("Reminders for water hydration, workouts, and sleep.");

            NotificationChannel milestoneChannel = new NotificationChannel(
                    CHANNEL_MILESTONES,
                    "Step Milestones",
                    NotificationManager.IMPORTANCE_HIGH
            );
            milestoneChannel.setDescription("Celebratory notifications when you reach step and fitness milestones.");

            manager.createNotificationChannel(reminderChannel);
            manager.createNotificationChannel(milestoneChannel);
        }
    }

    public static void showNotification(Context context, int id, String title, String message, String channelId) {
        createNotificationChannels(context);

        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        try {
            NotificationManagerCompat.from(context).notify(id, builder.build());
        } catch (SecurityException ignored) {
            // Android 13+ POST_NOTIFICATIONS permission handled at runtime
        }
    }

    public static void showStepMilestone(Context context, int percentage) {
        String title;
        String message;
        if (percentage >= 100) {
            title = "🎉 Step Goal Reached!";
            message = "Congratulations! You crushed your daily step goal. Keep up the phenomenal work!";
        } else if (percentage >= 75) {
            title = "🔥 75% Goal Completed!";
            message = "Awesome! You're almost there! Just a short walk away from the finish line.";
        } else {
            title = "💪 Halfway There!";
            message = "Great progress! You are 50% towards your daily step target.";
        }

        showNotification(context, 200 + percentage, title, message, CHANNEL_MILESTONES);
    }
}
