package com.example.fitlife.activities;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fitlife.R;
import com.example.fitlife.adapters.GoalsAdapter;
import com.example.fitlife.firebase.FirebaseHelper;
import com.example.fitlife.models.Goal;
import com.example.fitlife.notifications.NotificationHelper;
import com.example.fitlife.utils.SessionManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class GoalsActivity extends AppCompatActivity implements GoalsAdapter.OnGoalActionListener {

    private RecyclerView rvGoals;
    private GoalsAdapter adapter;
    private FloatingActionButton fabAddGoal;
    private List<Goal> goalList = new ArrayList<>();
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goals);

        sessionManager = new SessionManager(this);
        rvGoals = findViewById(R.id.rvGoals);
        fabAddGoal = findViewById(R.id.fabAddGoal);

        findViewById(R.id.btnBackGoals).setOnClickListener(v -> finish());

        rvGoals.setLayoutManager(new LinearLayoutManager(this));
        adapter = new GoalsAdapter(this);
        rvGoals.setAdapter(adapter);

        fabAddGoal.setOnClickListener(v -> showGoalDialog(null));

        loadDefaultOrFirebaseGoals();
    }

    private void loadDefaultOrFirebaseGoals() {
        String uid = sessionManager.getUserId();
        FirebaseHelper.getInstance().attachGoalsListener(uid, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                goalList.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot child : snapshot.getChildren()) {
                        Goal g = child.getValue(Goal.class);
                        if (g != null) goalList.add(g);
                    }
                }
                if (goalList.isEmpty()) {
                    // Pre-populate with realistic fitness goals
                    goalList.add(new Goal("goal_1", uid, "Steps", "Daily Step Target", 7500, 10000, "steps"));
                    goalList.add(new Goal("goal_2", uid, "Calories", "Burn Active Calories", 450, 600, "kcal"));
                    goalList.add(new Goal("goal_3", uid, "Water", "Hydration Target", 5, 8, "glasses"));
                    goalList.add(new Goal("goal_4", uid, "Distance", "Walking Distance", 5.6, 8.0, "km"));
                    goalList.add(new Goal("goal_5", uid, "Workout", "Active Exercise", 30, 45, "mins"));
                }
                adapter.setGoals(goalList);
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void showGoalDialog(Goal existingGoal) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_goal, null);
        EditText etTitle = dialogView.findViewById(R.id.etGoalTitle);
        EditText etTarget = dialogView.findViewById(R.id.etGoalTarget);
        EditText etCurrent = dialogView.findViewById(R.id.etGoalCurrent);
        Spinner spinnerType = dialogView.findViewById(R.id.spinnerGoalType);

        String[] types = {"Steps", "Calories", "Distance", "Water", "Weight", "Workout"};
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, types);
        spinnerType.setAdapter(typeAdapter);

        if (existingGoal != null) {
            etTitle.setText(existingGoal.getTitle());
            etTarget.setText(String.valueOf(existingGoal.getTarget()));
            etCurrent.setText(String.valueOf(existingGoal.getCurrentProgress()));
            for (int i = 0; i < types.length; i++) {
                if (types[i].equalsIgnoreCase(existingGoal.getType())) {
                    spinnerType.setSelection(i);
                    break;
                }
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(existingGoal == null ? "Create New Goal" : "Edit Goal")
                .setView(dialogView)
                .setPositiveButton(existingGoal == null ? "Create" : "Update", (dialog, which) -> {
                    String title = etTitle.getText().toString().trim();
                    String targetStr = etTarget.getText().toString().trim();
                    String currentStr = etCurrent.getText().toString().trim();
                    String selectedType = spinnerType.getSelectedItem().toString();

                    if (title.isEmpty() || targetStr.isEmpty()) {
                        Toast.makeText(this, "Title and Target are required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double target = Double.parseDouble(targetStr);
                    double current = currentStr.isEmpty() ? 0 : Double.parseDouble(currentStr);

                    String unit = "units";
                    if (selectedType.equals("Steps")) unit = "steps";
                    else if (selectedType.equals("Calories")) unit = "kcal";
                    else if (selectedType.equals("Distance")) unit = "km";
                    else if (selectedType.equals("Water")) unit = "glasses";
                    else if (selectedType.equals("Weight")) unit = "kg";
                    else if (selectedType.equals("Workout")) unit = "mins";

                    String uid = sessionManager.getUserId();
                    String goalId = existingGoal != null ? existingGoal.getId() : "goal_" + System.currentTimeMillis();
                    Goal goal = new Goal(goalId, uid, selectedType, title, current, target, unit);

                    FirebaseHelper.getInstance().saveGoal(uid, goal, task -> {
                        Toast.makeText(this, "Goal saved!", Toast.LENGTH_SHORT).show();
                        if (goal.getPercentage() >= 100) {
                            showCelebrationDialog(goal);
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showCelebrationDialog(Goal goal) {
        NotificationHelper.showNotification(
                this, 301, "🎉 Goal Accomplished!",
                "Congratulations! You completed your " + goal.getTitle() + "!",
                NotificationHelper.CHANNEL_MILESTONES
        );

        new AlertDialog.Builder(this)
                .setTitle("🎉 Congratulations!")
                .setMessage("You achieved 100% of your goal: \"" + goal.getTitle() + "\"!\nKeep striving for continuous fitness excellence!")
                .setPositiveButton("Awesome!", (dialog, which) -> dialog.dismiss())
                .show();
    }

    @Override
    public void onEdit(Goal goal) {
        showGoalDialog(goal);
    }

    @Override
    public void onDelete(Goal goal) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Goal")
                .setMessage("Are you sure you want to remove this goal?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    String uid = sessionManager.getUserId();
                    FirebaseHelper.getInstance().deleteGoal(uid, goal.getId(), task -> {
                        Toast.makeText(this, "Goal deleted", Toast.LENGTH_SHORT).show();
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
