package com.example.fitlife.models;

import java.io.Serializable;

public class ChatMessage implements Serializable {
    public static final int TYPE_USER = 0;
    public static final int TYPE_ASSISTANT = 1;

    private String id;
    private String text;
    private int senderType;
    private long timestamp;

    public ChatMessage() {}

    public ChatMessage(String id, String text, int senderType) {
        this.id = id;
        this.text = text;
        this.senderType = senderType;
        this.timestamp = System.currentTimeMillis();
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    public int getSenderType() { return senderType; }
    public void setSenderType(int senderType) { this.senderType = senderType; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public boolean isUser() {
        return senderType == TYPE_USER;
    }
}
