package com.example.fitlife.models;

import java.io.Serializable;

public class ActivityLog implements Serializable {
    private String id;
    private String userId;
    private String type; // Walking, Running, Cycling, Workout
    private long startTime;
    private long endTime;
    private long durationSeconds;
    private int steps;
    private double distanceKm;
    private int calories;
    private String date; // YYYY-MM-DD

    public ActivityLog() {
        // Firebase required
    }

    public ActivityLog(String id, String userId, String type, long startTime, long endTime,
                       long durationSeconds, int steps, double distanceKm, int calories, String date) {
        this.id = id;
        this.userId = userId;
        this.type = type;
        this.startTime = startTime;
        this.endTime = endTime;
        this.durationSeconds = durationSeconds;
        this.steps = steps;
        this.distanceKm = distanceKm;
        this.calories = calories;
        this.date = date;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public long getStartTime() { return startTime; }
    public void setStartTime(long startTime) { this.startTime = startTime; }

    public long getEndTime() { return endTime; }
    public void setEndTime(long endTime) { this.endTime = endTime; }

    public long getDurationSeconds() { return durationSeconds; }
    public void setDurationSeconds(long durationSeconds) { this.durationSeconds = durationSeconds; }

    public int getSteps() { return steps; }
    public void setSteps(int steps) { this.steps = steps; }

    public double getDistanceKm() { return distanceKm; }
    public void setDistanceKm(double distanceKm) { this.distanceKm = distanceKm; }

    public int getCalories() { return calories; }
    public void setCalories(int calories) { this.calories = calories; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
}
