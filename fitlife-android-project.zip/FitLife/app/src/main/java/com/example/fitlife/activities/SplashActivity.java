package com.example.fitlife.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fitlife.R;
import com.example.fitlife.firebase.FirebaseHelper;
import com.example.fitlife.utils.SessionManager;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            SessionManager session = new SessionManager(this);
            boolean hasFirebaseUser = FirebaseHelper.getInstance().getCurrentUser() != null;

            if (session.isLoggedIn() || hasFirebaseUser) {
                // User already logged in, navigate straight to main dashboard
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
            } else {
                // Navigate to login
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            }
            finish();
        }, 1800);
    }
}
