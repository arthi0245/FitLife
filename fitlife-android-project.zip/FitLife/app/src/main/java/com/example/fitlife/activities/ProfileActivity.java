package com.example.fitlife.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fitlife.R;
import com.example.fitlife.firebase.FirebaseHelper;
import com.example.fitlife.models.User;
import com.example.fitlife.utils.BMICalculator;
import com.example.fitlife.utils.SessionManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class ProfileActivity extends AppCompatActivity {

    private EditText etName, etAge, etHeight, etWeight;
    private Spinner spinnerGender, spinnerFitnessLevel, spinnerGoal;
    private TextView tvBmiValue, tvBmiCategory, tvBmiHealthMessage;
    private Button btnSaveProfile;
    private ProgressBar progressBar;

    private SessionManager sessionManager;
    private User currentUser;
    private boolean isFirstSetup = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        sessionManager = new SessionManager(this);
        isFirstSetup = getIntent().getBooleanExtra("isFirstSetup", false);

        initViews();
        setupSpinners();
        setupLiveBMICalculation();
        loadProfileData();

        btnSaveProfile.setOnClickListener(v -> saveProfile());
    }

    private void initViews() {
        etName = findViewById(R.id.etProfileName);
        etAge = findViewById(R.id.etProfileAge);
        etHeight = findViewById(R.id.etProfileHeight);
        etWeight = findViewById(R.id.etProfileWeight);
        spinnerGender = findViewById(R.id.spinnerGender);
        spinnerFitnessLevel = findViewById(R.id.spinnerFitnessLevel);
        spinnerGoal = findViewById(R.id.spinnerGoal);
        tvBmiValue = findViewById(R.id.tvBmiValue);
        tvBmiCategory = findViewById(R.id.tvBmiCategory);
        tvBmiHealthMessage = findViewById(R.id.tvBmiHealthMessage);
        btnSaveProfile = findViewById(R.id.btnSaveProfile);
        progressBar = findViewById(R.id.progressBarProfile);
    }

    private void setupSpinners() {
        String[] genders = {"Female", "Male", "Other", "Prefer not to say"};
        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, genders);
        spinnerGender.setAdapter(genderAdapter);

        String[] levels = {"Beginner", "Intermediate", "Advanced", "Athlete"};
        ArrayAdapter<String> levelAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, levels);
        spinnerFitnessLevel.setAdapter(levelAdapter);

        String[] goals = {"Weight Loss", "Muscle Gain", "Endurance & Stamina", "Maintenance & Wellness"};
        ArrayAdapter<String> goalAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, goals);
        spinnerGoal.setAdapter(goalAdapter);
    }

    private void setupLiveBMICalculation() {
        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int count, int after) {
                updateLiveBMI();
            }
            @Override public void afterTextChanged(Editable s) {}
        };

        etHeight.addTextChangedListener(watcher);
        etWeight.addTextChangedListener(watcher);
    }

    private void updateLiveBMI() {
        try {
            double h = Double.parseDouble(etHeight.getText().toString());
            double w = Double.parseDouble(etWeight.getText().toString());
            if (h > 50 && w > 20) {
                double bmi = BMICalculator.calculateBMI(w, h);
                String cat = BMICalculator.getCategory(bmi);
                String msg = BMICalculator.getHealthMessage(bmi);

                tvBmiValue.setText(String.format(java.util.Locale.getDefault(), "BMI: %.1f", bmi));
                tvBmiCategory.setText(cat);
                tvBmiHealthMessage.setText(msg);
            }
        } catch (NumberFormatException ignored) {}
    }

    private void loadProfileData() {
        String uid = sessionManager.getUserId();
        progressBar.setVisibility(View.VISIBLE);

        FirebaseHelper.getInstance().getUserProfile(uid, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressBar.setVisibility(View.GONE);
                if (snapshot.exists()) {
                    currentUser = snapshot.getValue(User.class);
                    if (currentUser != null) {
                        etName.setText(currentUser.getName());
                        etAge.setText(String.valueOf(currentUser.getAge()));
                        etHeight.setText(String.valueOf(currentUser.getHeightCm()));
                        etWeight.setText(String.valueOf(currentUser.getWeightKg()));
                        updateLiveBMI();
                    }
                } else {
                    etName.setText(sessionManager.getUserName());
                    etAge.setText("25");
                    etHeight.setText("175.0");
                    etWeight.setText("70.0");
                    updateLiveBMI();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    private void saveProfile() {
        String name = etName.getText().toString().trim();
        if (name.isEmpty()) {
            etName.setError("Name is required");
            return;
        }

        double height = 175.0;
        double weight = 70.0;
        int age = 25;

        try {
            height = Double.parseDouble(etHeight.getText().toString().trim());
            weight = Double.parseDouble(etWeight.getText().toString().trim());
            age = Integer.parseInt(etAge.getText().toString().trim());
        } catch (Exception ignored) {}

        String gender = spinnerGender.getSelectedItem() != null ? spinnerGender.getSelectedItem().toString() : "Not Specified";
        String level = spinnerFitnessLevel.getSelectedItem() != null ? spinnerFitnessLevel.getSelectedItem().toString() : "Intermediate";
        String goal = spinnerGoal.getSelectedItem() != null ? spinnerGoal.getSelectedItem().toString() : "Weight Loss";

        String uid = sessionManager.getUserId();
        if (currentUser == null) {
            currentUser = new User(uid, name, sessionManager.getUserEmail());
        }
        currentUser.setName(name);
        currentUser.setAge(age);
        currentUser.setGender(gender);
        currentUser.setHeightCm(height);
        currentUser.setWeightKg(weight);
        currentUser.setFitnessLevel(level);
        currentUser.setFitnessGoal(goal);

        progressBar.setVisibility(View.VISIBLE);
        btnSaveProfile.setEnabled(false);

        FirebaseHelper.getInstance().saveUserProfile(currentUser, task -> {
            progressBar.setVisibility(View.GONE);
            btnSaveProfile.setEnabled(true);

            if (task.isSuccessful()) {
                sessionManager.setLogin(true, uid, name, currentUser.getEmail());
                Toast.makeText(ProfileActivity.this, "Profile updated and synchronized!", Toast.LENGTH_SHORT).show();

                if (isFirstSetup) {
                    startActivity(new Intent(ProfileActivity.this, MainActivity.class));
                }
                finish();
            } else {
                Toast.makeText(ProfileActivity.this, "Failed to save profile. Saved locally.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
