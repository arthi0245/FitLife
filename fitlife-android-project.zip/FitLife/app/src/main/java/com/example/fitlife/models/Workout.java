package com.example.fitlife.models;

import java.io.Serializable;

public class Workout implements Serializable {
    private String id;
    private String name;
    private String category; // Cardio, Strength Training, Yoga, HIIT, Stretching
    private int durationMinutes;
    private int estimatedCalories;
    private String difficulty; // Beginner, Intermediate, Advanced
    private String description;
    private String iconName;

    public Workout() {}

    public Workout(String id, String name, String category, int durationMinutes, int estimatedCalories, String difficulty, String description) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.durationMinutes = durationMinutes;
        this.estimatedCalories = estimatedCalories;
        this.difficulty = difficulty;
        this.description = description;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

    public int getEstimatedCalories() { return estimatedCalories; }
    public void setEstimatedCalories(int estimatedCalories) { this.estimatedCalories = estimatedCalories; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getIconName() { return iconName; }
    public void setIconName(String iconName) { this.iconName = iconName; }
}
