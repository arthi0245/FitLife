package com.example.fitlife.models;

import java.io.Serializable;

public class User implements Serializable {
    private String userId;
    private String name;
    private String email;
    private int age;
    private String gender;
    private double heightCm;
    private double weightKg;
    private String fitnessLevel; // Beginner, Intermediate, Advanced
    private String fitnessGoal;  // Weight Loss, Muscle Gain, Endurance, Maintenance
    private double strideLengthMeters;
    private String profileImageUrl;
    private long createdAt;

    public User() {
        // Required for Firebase
    }

    public User(String userId, String name, String email) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.age = 25;
        this.gender = "Not Specified";
        this.heightCm = 175.0;
        this.weightKg = 70.0;
        this.fitnessLevel = "Intermediate";
        this.fitnessGoal = "Weight Loss";
        this.strideLengthMeters = 0.76;
        this.createdAt = System.currentTimeMillis();
    }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public double getHeightCm() { return heightCm; }
    public void setHeightCm(double heightCm) { this.heightCm = heightCm; }

    public double getWeightKg() { return weightKg; }
    public void setWeightKg(double weightKg) { this.weightKg = weightKg; }

    public String getFitnessLevel() { return fitnessLevel; }
    public void setFitnessLevel(String fitnessLevel) { this.fitnessLevel = fitnessLevel; }

    public String getFitnessGoal() { return fitnessGoal; }
    public void setFitnessGoal(String fitnessGoal) { this.fitnessGoal = fitnessGoal; }

    public double getStrideLengthMeters() {
        if (strideLengthMeters <= 0) {
            // Default estimation based on height or standard 0.415 * height
            return heightCm > 0 ? (heightCm * 0.415) / 100.0 : 0.76;
        }
        return strideLengthMeters;
    }
    public void setStrideLengthMeters(double strideLengthMeters) { this.strideLengthMeters = strideLengthMeters; }

    public String getProfileImageUrl() { return profileImageUrl; }
    public void setProfileImageUrl(String profileImageUrl) { this.profileImageUrl = profileImageUrl; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}
