package com.example.fitlife.activities;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.fitlife.R;
import com.example.fitlife.firebase.FirebaseHelper;
import com.example.fitlife.models.HealthData;
import com.example.fitlife.models.User;
import com.example.fitlife.notifications.NotificationHelper;
import com.example.fitlife.utils.BMICalculator;
import com.example.fitlife.utils.FitnessScoreCalculator;
import com.example.fitlife.utils.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    // UI elements
    private TextView tvWelcomeUser, tvTodaySteps, tvStepGoalRatio;
    private TextView tvCaloriesBurned, tvCalorieGoalRatio;
    private TextView tvDistance, tvActiveMins;
    private TextView tvWeight, tvBmi, tvFitnessScore, tvScoreCategory, tvScoreMessage;
    private TextView tvWaterProgress, tvSensorStatus;
    private ProgressBar pbSteps, pbCalories, pbWater;

    private CardView cardFood, cardWorkout, cardGoals, cardHealth, cardStepTracker;
    private BottomNavigationView bottomNav;

    // State & helpers
    private SessionManager sessionManager;
    private SensorManager sensorManager;
    private Sensor stepSensor;
    private boolean isSensorPresent = false;
    private int initialSensorSteps = -1;

    private int todaySteps = 7500;
    private int todayCalories = 450;
    private double todayDistanceKm = 5.7;
    private int todayActiveMins = 38;
    private int todayWaterGlasses = 5;
    private double userWeight = 70.0;
    private double userHeight = 175.0;

    private boolean milestone50Sent = false;
    private boolean milestone75Sent = false;
    private boolean milestone100Sent = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        sessionManager = new SessionManager(this);
        initViews();
        setupBottomNavigation();
        setupSensorTracking();
        setupQuickActionCards();
        loadFirebaseData();
        recalculateAndRefreshUI();
    }

    private void initViews() {
        tvWelcomeUser = findViewById(R.id.tvWelcomeUser);
        tvTodaySteps = findViewById(R.id.tvTodaySteps);
        tvStepGoalRatio = findViewById(R.id.tvStepGoalRatio);
        tvCaloriesBurned = findViewById(R.id.tvCaloriesBurned);
        tvCalorieGoalRatio = findViewById(R.id.tvCalorieGoalRatio);
        tvDistance = findViewById(R.id.tvDistance);
        tvActiveMins = findViewById(R.id.tvActiveMins);
        tvWeight = findViewById(R.id.tvWeight);
        tvBmi = findViewById(R.id.tvBmi);
        tvFitnessScore = findViewById(R.id.tvFitnessScore);
        tvScoreCategory = findViewById(R.id.tvScoreCategory);
        tvScoreMessage = findViewById(R.id.tvScoreMessage);
        tvWaterProgress = findViewById(R.id.tvWaterProgress);
        tvSensorStatus = findViewById(R.id.tvSensorStatus);

        pbSteps = findViewById(R.id.pbSteps);
        pbCalories = findViewById(R.id.pbCalories);
        pbWater = findViewById(R.id.pbWater);

        cardFood = findViewById(R.id.cardFood);
        cardWorkout = findViewById(R.id.cardWorkout);
        cardGoals = findViewById(R.id.cardGoals);
        cardHealth = findViewById(R.id.cardHealth);
        cardStepTracker = findViewById(R.id.cardStepTracker);
        bottomNav = findViewById(R.id.bottomNavigationView);

        tvWelcomeUser.setText("Hello, " + sessionManager.getUserName() + " 👋");
    }

    private void setupBottomNavigation() {
        bottomNav.setSelectedItemId(R.id.nav_dashboard);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_dashboard) {
                return true;
            } else if (id == R.id.nav_activity) {
                startActivity(new Intent(MainActivity.this, ActivityTrackerActivity.class));
                return true;
            } else if (id == R.id.nav_reports) {
                startActivity(new Intent(MainActivity.this, ReportsActivity.class));
                return true;
            } else if (id == R.id.nav_assistant) {
                startActivity(new Intent(MainActivity.this, AssistantActivity.class));
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(MainActivity.this, ProfileActivity.class));
                return true;
            }
            return false;
        });
    }

    private void setupQuickActionCards() {
        cardFood.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, FoodRecommendationActivity.class)));
        cardWorkout.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, WorkoutActivity.class)));
        cardGoals.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, GoalsActivity.class)));
        cardHealth.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, HealthTrackingActivity.class)));

        cardStepTracker.setOnClickListener(v -> {
            // Trigger quick step simulation if sensor is unavailable, or open Activity Tracker
            if (!isSensorPresent) {
                todaySteps += 120;
                todayCalories += 6;
                todayDistanceKm += 0.09;
                recalculateAndRefreshUI();
                syncToFirebase();
                Toast.makeText(this, "+120 Steps added in Demo Mode", Toast.LENGTH_SHORT).show();
            } else {
                startActivity(new Intent(MainActivity.this, ActivityTrackerActivity.class));
            }
        });
    }

    private void setupSensorTracking() {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            if (stepSensor == null) {
                stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            }
        }

        if (stepSensor != null) {
            isSensorPresent = true;
            tvSensorStatus.setText("● Hardware Step Sensor Active");
        } else {
            isSensorPresent = false;
            tvSensorStatus.setText("⚠ Step sensor unavailable • Demo Mode Enabled");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isSensorPresent && stepSensor != null && sensorManager != null) {
            sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI);
        }
        bottomNav.setSelectedItemId(R.id.nav_dashboard);
        recalculateAndRefreshUI();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isSensorPresent && sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            int totalStepsSinceReboot = (int) event.values[0];
            if (initialSensorSteps < 0) {
                initialSensorSteps = totalStepsSinceReboot;
            }
            int delta = totalStepsSinceReboot - initialSensorSteps;
            todaySteps += delta;
            initialSensorSteps = totalStepsSinceReboot;
        } else if (event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            todaySteps += 1;
        }

        // Recalculate distance and calories from user stride
        double stride = (userHeight * 0.415) / 100.0;
        todayDistanceKm = Math.round(((todaySteps * stride) / 1000.0) * 100.0) / 100.0;
        todayCalories = (int) Math.round(todaySteps * 0.045);

        recalculateAndRefreshUI();
        syncToFirebase();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private void recalculateAndRefreshUI() {
        int stepGoal = sessionManager.getStepGoal();
        int calGoal = sessionManager.getCalorieGoal();
        int waterGoal = sessionManager.getWaterGoal();

        tvTodaySteps.setText(String.format(Locale.getDefault(), "%,d", todaySteps));
        tvStepGoalRatio.setText(String.format(Locale.getDefault(), "%,d / %,d steps", todaySteps, stepGoal));
        pbSteps.setMax(stepGoal);
        pbSteps.setProgress(Math.min(todaySteps, stepGoal));

        tvCaloriesBurned.setText(String.format(Locale.getDefault(), "%,d kcal", todayCalories));
        tvCalorieGoalRatio.setText(String.format(Locale.getDefault(), "%,d / %,d kcal", todayCalories, calGoal));
        pbCalories.setMax(calGoal);
        pbCalories.setProgress(Math.min(todayCalories, calGoal));

        tvDistance.setText(String.format(Locale.getDefault(), "%.2f km", todayDistanceKm));
        tvActiveMins.setText(todayActiveMins + " min");
        tvWeight.setText(String.format(Locale.getDefault(), "%.1f kg", userWeight));

        double bmi = BMICalculator.calculateBMI(userWeight, userHeight);
        tvBmi.setText(String.format(Locale.getDefault(), "%.1f (%s)", bmi, BMICalculator.getCategory(bmi)));

        tvWaterProgress.setText(String.format(Locale.getDefault(), "%d / %d glasses", todayWaterGlasses, waterGoal));
        pbWater.setMax(waterGoal);
        pbWater.setProgress(Math.min(todayWaterGlasses, waterGoal));

        // Fitness score calculation
        FitnessScoreCalculator.ScoreResult scoreRes = FitnessScoreCalculator.calculateScore(
                todaySteps, stepGoal,
                todayCalories, calGoal,
                todayActiveMins, 30,
                todayWaterGlasses, waterGoal,
                7.5
        );

        tvFitnessScore.setText(scoreRes.score + "/100");
        tvScoreCategory.setText(scoreRes.category);
        tvScoreMessage.setText(scoreRes.message);

        checkStepMilestones(todaySteps, stepGoal);
    }

    private void checkStepMilestones(int steps, int goal) {
        if (goal <= 0) return;
        int pct = (int) Math.round((steps / (double) goal) * 100);

        if (pct >= 100 && !milestone100Sent) {
            milestone100Sent = true;
            NotificationHelper.showStepMilestone(this, 100);
            Toast.makeText(this, "🎉 Congratulations! You reached your daily step goal!", Toast.LENGTH_LONG).show();
        } else if (pct >= 75 && !milestone75Sent) {
            milestone75Sent = true;
            NotificationHelper.showStepMilestone(this, 75);
        } else if (pct >= 50 && !milestone50Sent) {
            milestone50Sent = true;
            NotificationHelper.showStepMilestone(this, 50);
        }
    }

    private void loadFirebaseData() {
        String uid = sessionManager.getUserId();

        FirebaseHelper.getInstance().getUserProfile(uid, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    User user = snapshot.getValue(User.class);
                    if (user != null) {
                        userWeight = user.getWeightKg();
                        userHeight = user.getHeightCm();
                        tvWelcomeUser.setText("Hello, " + user.getName() + " 👋");
                        recalculateAndRefreshUI();
                    }
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });

        FirebaseHelper.getInstance().attachTodayActivityListener(uid, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Integer steps = snapshot.child("steps").getValue(Integer.class);
                    Integer cals = snapshot.child("caloriesBurned").getValue(Integer.class);
                    Double dist = snapshot.child("distanceKm").getValue(Double.class);
                    if (steps != null) todaySteps = steps;
                    if (cals != null) todayCalories = cals;
                    if (dist != null) todayDistanceKm = dist;
                    recalculateAndRefreshUI();
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void syncToFirebase() {
        String uid = sessionManager.getUserId();
        FirebaseHelper.getInstance().syncDailySteps(uid, todaySteps, todayCalories, todayDistanceKm);
    }
}
