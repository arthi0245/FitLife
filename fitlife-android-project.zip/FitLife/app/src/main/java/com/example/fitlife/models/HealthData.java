package com.example.fitlife.models;

import java.io.Serializable;

public class HealthData implements Serializable {
    private String date; // YYYY-MM-DD
    private String userId;
    private double weightKg;
    private double heightCm;
    private int waterGlasses;
    private int waterGoal;
    private double sleepHours;
    private int steps;
    private int caloriesBurned;
    private double distanceKm;
    private int activeMinutes;
    private int caloriesConsumed;
    private int proteinGrams;
    private int carbsGrams;
    private int fitnessScore;

    public HealthData() {
        this.waterGoal = 8;
        this.sleepHours = 7.0;
    }

    public HealthData(String date, String userId) {
        this.date = date;
        this.userId = userId;
        this.waterGoal = 8;
        this.waterGlasses = 0;
        this.sleepHours = 7.0;
        this.steps = 0;
        this.caloriesBurned = 0;
        this.distanceKm = 0.0;
        this.activeMinutes = 0;
        this.caloriesConsumed = 0;
        this.proteinGrams = 0;
        this.carbsGrams = 0;
        this.fitnessScore = 50;
    }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public double getWeightKg() { return weightKg; }
    public void setWeightKg(double weightKg) { this.weightKg = weightKg; }

    public double getHeightCm() { return heightCm; }
    public void setHeightCm(double heightCm) { this.heightCm = heightCm; }

    public int getWaterGlasses() { return waterGlasses; }
    public void setWaterGlasses(int waterGlasses) { this.waterGlasses = waterGlasses; }

    public int getWaterGoal() { return waterGoal; }
    public void setWaterGoal(int waterGoal) { this.waterGoal = waterGoal; }

    public double getSleepHours() { return sleepHours; }
    public void setSleepHours(double sleepHours) { this.sleepHours = sleepHours; }

    public int getSteps() { return steps; }
    public void setSteps(int steps) { this.steps = steps; }

    public int getCaloriesBurned() { return caloriesBurned; }
    public void setCaloriesBurned(int caloriesBurned) { this.caloriesBurned = caloriesBurned; }

    public double getDistanceKm() { return distanceKm; }
    public void setDistanceKm(double distanceKm) { this.distanceKm = distanceKm; }

    public int getActiveMinutes() { return activeMinutes; }
    public void setActiveMinutes(int activeMinutes) { this.activeMinutes = activeMinutes; }

    public int getCaloriesConsumed() { return caloriesConsumed; }
    public void setCaloriesConsumed(int caloriesConsumed) { this.caloriesConsumed = caloriesConsumed; }

    public int getProteinGrams() { return proteinGrams; }
    public void setProteinGrams(int proteinGrams) { this.proteinGrams = proteinGrams; }

    public int getCarbsGrams() { return carbsGrams; }
    public void setCarbsGrams(int carbsGrams) { this.carbsGrams = carbsGrams; }

    public int getFitnessScore() { return fitnessScore; }
    public void setFitnessScore(int fitnessScore) { this.fitnessScore = fitnessScore; }
}
