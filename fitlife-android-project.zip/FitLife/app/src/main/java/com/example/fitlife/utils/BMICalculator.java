package com.example.fitlife.utils;

import java.util.Locale;

public class BMICalculator {

    public static double calculateBMI(double weightKg, double heightCm) {
        if (heightCm <= 0 || weightKg <= 0) return 0.0;
        double heightM = heightCm / 100.0;
        double bmi = weightKg / (heightM * heightM);
        return Math.round(bmi * 10.0) / 10.0;
    }

    public static String getCategory(double bmi) {
        if (bmi <= 0) return "Unknown";
        if (bmi < 18.5) return "Underweight";
        if (bmi < 25.0) return "Normal";
        if (bmi < 30.0) return "Overweight";
        return "Obese";
    }

    public static String getHealthMessage(double bmi) {
        if (bmi <= 0) {
            return "Please enter your valid height and weight to calculate your personalized BMI insights.";
        }
        if (bmi < 18.5) {
            return "Your BMI indicates you are underweight. Consider nutrient-dense, protein-rich foods and strength training to build lean muscle mass.";
        } else if (bmi < 25.0) {
            return "Your BMI is in the healthy range! Keep maintaining your active lifestyle and balanced nutrition.";
        } else if (bmi < 30.0) {
            return "Your BMI falls in the overweight range. Incorporating daily brisk walking, portion awareness, and regular aerobic workouts will help reach your target.";
        } else {
            return "Your BMI is in the obese range. Prioritize consistent low-impact daily movement, hydration, and consult a healthcare professional for structured guidance.";
        }
    }
}
