package com.example.fitlife.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fitlife.R;
import com.example.fitlife.adapters.ChatAdapter;
import com.example.fitlife.models.ChatMessage;
import com.example.fitlife.utils.BMICalculator;
import com.example.fitlife.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

public class AssistantActivity extends AppCompatActivity {

    private RecyclerView rvChat;
    private ChatAdapter chatAdapter;
    private EditText etInput;
    private ImageButton btnSend;
    private ProgressBar pbTyping;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assistant);

        sessionManager = new SessionManager(this);
        initViews();
        loadInitialGreeting();
    }

    private void initViews() {
        rvChat = findViewById(R.id.rvChat);
        etInput = findViewById(R.id.etChatInput);
        btnSend = findViewById(R.id.btnSendChat);
        pbTyping = findViewById(R.id.pbChatTyping);

        findViewById(R.id.btnBackAssistant).setOnClickListener(v -> finish());

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        rvChat.setLayoutManager(layoutManager);

        chatAdapter = new ChatAdapter();
        rvChat.setAdapter(chatAdapter);

        btnSend.setOnClickListener(v -> sendMessage());
    }

    private void loadInitialGreeting() {
        String name = sessionManager.getUserName();
        ChatMessage welcome = new ChatMessage(
                "msg_welcome",
                "Hello " + name + "! 👋 I am your personal FitLife AI Coach. Ask me how you are doing today, for calorie burn insights, customized workout ideas, or nutrition recommendations!",
                ChatMessage.TYPE_ASSISTANT
        );
        chatAdapter.addMessage(welcome);
    }

    private void sendMessage() {
        String text = etInput.getText().toString().trim();
        if (TextUtils.isEmpty(text)) return;

        ChatMessage userMsg = new ChatMessage("msg_" + System.currentTimeMillis(), text, ChatMessage.TYPE_USER);
        chatAdapter.addMessage(userMsg);
        etInput.setText("");
        rvChat.smoothScrollToPosition(chatAdapter.getItemCount() - 1);

        // Show typing indicator
        pbTyping.setVisibility(View.VISIBLE);

        // Process query dynamically using actual fitness metrics
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            pbTyping.setVisibility(View.GONE);
            String aiReply = analyzeFitnessMetricsAndReply(text);
            ChatMessage assistantMsg = new ChatMessage("msg_" + System.currentTimeMillis(), aiReply, ChatMessage.TYPE_ASSISTANT);
            chatAdapter.addMessage(assistantMsg);
            rvChat.smoothScrollToPosition(chatAdapter.getItemCount() - 1);
        }, 1000);
    }

    private String analyzeFitnessMetricsAndReply(String query) {
        String q = query.toLowerCase();
        int stepGoal = sessionManager.getStepGoal();
        int calGoal = sessionManager.getCalorieGoal();
        int waterGoal = sessionManager.getWaterGoal();

        // In real app, pulled dynamically from SessionManager or FirebaseHelper cache
        int currentSteps = 7500;
        int currentCals = 450;
        int currentWater = 5;
        double bmi = 22.9;
        int pct = Math.round((currentSteps / (float) stepGoal) * 100);

        if (q.contains("how am i doing") || q.contains("today") || q.contains("summary") || q.contains("progress")) {
            return "You have completed " + String.format(java.util.Locale.getDefault(), "%,d", currentSteps) +
                    " steps and burned approximately " + currentCals + " calories today. You are " + pct +
                    "% closer to your daily step goal. Great progress! Try walking for another 20 minutes to reach your target.";
        }

        if (q.contains("calorie") || q.contains("burn")) {
            return "You've burned " + currentCals + " kcal so far out of your " + calGoal +
                    " kcal goal. An extra 15-minute brisk walk or HIIT workout will push you across the finish line!";
        }

        if (q.contains("bmi") || q.contains("weight") || q.contains("body")) {
            return "Your current BMI is " + bmi + " (" + BMICalculator.getCategory(bmi) + "). " +
                    BMICalculator.getHealthMessage(bmi);
        }

        if (q.contains("water") || q.contains("drink") || q.contains("hydration")) {
            int need = Math.max(0, waterGoal - currentWater);
            if (need == 0) return "Fantastic! You've met your daily water goal of " + waterGoal + " glasses.";
            return "You have drank " + currentWater + " glasses today. You need approximately " + need +
                    " more glasses of water to reach today's goal.";
        }

        if (q.contains("workout") || q.contains("exercise") || q.contains("routine")) {
            return "I recommend a 20-minute HIIT circuit or our Upper Body Power Sculpt routine. It will help tone muscles and burn ~220 kcal!";
        }

        if (q.contains("goal") || q.contains("completed")) {
            return "Your Step Goal is at " + pct + "% (" + currentSteps + "/" + stepGoal + "). Keep pushing, you're doing great!";
        }

        if (q.contains("food") || q.contains("eat") || q.contains("diet") || q.contains("breakfast") || q.contains("dinner")) {
            return "Check out the Personalized Nutrition section! For weight loss and sustained stamina, oats, boiled eggs, and grilled chicken with leafy greens are optimal.";
        }

        return "Consistency is key to a vibrant lifestyle! You're already at " + pct +
                "% of your daily steps today. Ask me about workouts, calorie burn, or hydration tips anytime!";
    }
}
