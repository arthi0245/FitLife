package com.example.fitlife.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fitlife.R;
import com.example.fitlife.models.Workout;

import java.util.ArrayList;
import java.util.List;

public class WorkoutAdapter extends RecyclerView.Adapter<WorkoutAdapter.WorkoutViewHolder> {

    public interface OnWorkoutClickListener {
        void onStartWorkout(Workout workout);
    }

    private List<Workout> workoutList = new ArrayList<>();
    private final OnWorkoutClickListener listener;

    public WorkoutAdapter(OnWorkoutClickListener listener) {
        this.listener = listener;
    }

    public void setWorkouts(List<Workout> workouts) {
        this.workoutList = workouts != null ? workouts : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public WorkoutViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_workout, parent, false);
        return new WorkoutViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkoutViewHolder holder, int position) {
        Workout workout = workoutList.get(position);
        holder.bind(workout, listener);
    }

    @Override
    public int getItemCount() {
        return workoutList.size();
    }

    static class WorkoutViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCategory, tvMeta, tvDescription;
        Button btnStart;

        public WorkoutViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvWorkoutName);
            tvCategory = itemView.findViewById(R.id.tvWorkoutCategory);
            tvMeta = itemView.findViewById(R.id.tvWorkoutMeta);
            tvDescription = itemView.findViewById(R.id.tvWorkoutDesc);
            btnStart = itemView.findViewById(R.id.btnStartWorkout);
        }

        public void bind(Workout workout, OnWorkoutClickListener listener) {
            tvName.setText(workout.getName());
            tvCategory.setText(workout.getCategory());
            String meta = workout.getDurationMinutes() + " mins • " + workout.getEstimatedCalories() + " kcal • " + workout.getDifficulty();
            tvMeta.setText(meta);
            tvDescription.setText(workout.getDescription());

            btnStart.setOnClickListener(v -> {
                if (listener != null) listener.onStartWorkout(workout);
            });
        }
    }
}
