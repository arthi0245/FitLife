package com.example.fitlife.activities;

import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fitlife.R;
import com.example.fitlife.adapters.FoodAdapter;
import com.example.fitlife.firebase.FirebaseHelper;
import com.example.fitlife.models.FoodItem;
import com.example.fitlife.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FoodRecommendationActivity extends AppCompatActivity implements FoodAdapter.OnFoodActionListener {

    private RecyclerView rvFood;
    private FoodAdapter adapter;
    private RadioGroup rgMealTabs;
    private TextView tvNutritionSummary, tvDisclaimer;

    private List<FoodItem> allFoods = new ArrayList<>();
    private int totalCaloriesConsumed = 0;
    private int totalProtein = 0;
    private int totalCarbs = 0;
    private int mealsCompleted = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        initViews();
        setupList();
        setupMealTabs();
        updateNutritionSummary();
    }

    private void initViews() {
        rvFood = findViewById(R.id.rvFood);
        rgMealTabs = findViewById(R.id.rgMealTabs);
        tvNutritionSummary = findViewById(R.id.tvNutritionSummary);
        tvDisclaimer = findViewById(R.id.tvFoodDisclaimer);

        findViewById(R.id.btnBackFood).setOnClickListener(v -> finish());
    }

    private void setupList() {
        rvFood.setLayoutManager(new LinearLayoutManager(this));
        adapter = new FoodAdapter(this);
        rvFood.setAdapter(adapter);

        // Populate realistic nutritional items
        // Breakfast
        allFoods.add(new FoodItem("f1", "Rolled Oats with Berries & Almonds", "BREAKFAST", 260, 9, 42,
                "1 bowl (50g oats)", "Rich in beta-glucan fiber, stabilizes morning glucose levels.", "Weight Loss"));
        allFoods.add(new FoodItem("f2", "Steamed Idli with Sambar & Coconut Chutney", "BREAKFAST", 210, 7, 38,
                "3 idlis (150g)", "Fermented gut-friendly probiotics, easy on digestion.", "Maintenance"));
        allFoods.add(new FoodItem("f3", "Boiled Eggs & Whole Grain Toast", "BREAKFAST", 280, 18, 22,
                "2 eggs + 1 slice", "High biological value complete protein, promotes satiety.", "Muscle Gain"));
        allFoods.add(new FoodItem("f4", "Vegetable Upma with Roasted Peanuts", "BREAKFAST", 240, 6, 36,
                "1 cup (180g)", "Sustained complex carbohydrate release for active mornings.", "Endurance"));

        // Lunch
        allFoods.add(new FoodItem("f5", "Brown Rice, Dal & Spinach Curry", "LUNCH", 420, 15, 68,
                "1 bowl rice + 1 cup dal", "Balanced amino acid profile with essential micronutrients.", "Weight Loss"));
        allFoods.add(new FoodItem("f6", "Whole Wheat Chapati with Paneer Bhurji", "LUNCH", 450, 22, 45,
                "2 chapatis + 100g paneer", "High calcium and muscle-building casein proteins.", "Muscle Gain"));
        allFoods.add(new FoodItem("f7", "Grilled Chicken Breast with Quinoa Salad", "LUNCH", 410, 38, 30,
                "150g chicken + salad", "Ultra-lean high protein meal supporting muscular recovery.", "Muscle Gain"));

        // Evening
        allFoods.add(new FoodItem("f8", "Sprouted Moong & Pomegranate Chaat", "EVENING", 160, 8, 26,
                "1 cup (150g)", "Loaded with active enzymes, vitamins, and dietary fiber.", "Weight Loss"));
        allFoods.add(new FoodItem("f9", "Green Tea with Roasted Mixed Nuts", "EVENING", 140, 5, 8,
                "1 mug + 20g nuts", "Potent EGCG catechins and heart-healthy monounsaturated fats.", "General Wellness"));
        allFoods.add(new FoodItem("f10", "Boiled Sweet Corn with Lemon & Herbs", "EVENING", 120, 4, 24,
                "1 medium cob", "Antioxidants lutein and zeaxanthin with low glycemic load.", "Maintenance"));

        // Dinner
        allFoods.add(new FoodItem("f11", "Light Vegetable Lentil Soup with Croutons", "DINNER", 190, 9, 28,
                "1 large bowl (300ml)", "Light on nighttime metabolism, reduces water retention.", "Weight Loss"));
        allFoods.add(new FoodItem("f12", "Multigrain Chapati with Mixed Vegetable Curry", "DINNER", 310, 10, 48,
                "2 thin rotis + sabzi", "Slow-burning complex carbs for uninterrupted sleep.", "Maintenance"));
        allFoods.add(new FoodItem("f13", "Grilled Tofu with Steamed Broccoli", "DINNER", 240, 20, 12,
                "150g tofu + greens", "Complete plant protein promoting nocturnal tissue repair.", "Muscle Gain"));

        // Healthy Snacks
        allFoods.add(new FoodItem("f14", "Greek Yogurt with Chia Seeds", "HEALTHY_SNACKS", 150, 15, 9,
                "1 small cup (120g)", "High density probiotics and omega-3 fatty acids.", "Weight Loss"));
        allFoods.add(new FoodItem("f15", "Apple Slices with 1 Tbsp Peanut Butter", "HEALTHY_SNACKS", 180, 5, 22,
                "1 medium apple", "Pectin fiber paired with satiating healthy fats.", "General Wellness"));

        filterFoods("BREAKFAST");
    }

    private void setupMealTabs() {
        rgMealTabs.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbTabBreakfast) filterFoods("BREAKFAST");
            else if (checkedId == R.id.rbTabLunch) filterFoods("LUNCH");
            else if (checkedId == R.id.rbTabEvening) filterFoods("EVENING");
            else if (checkedId == R.id.rbTabDinner) filterFoods("DINNER");
            else if (checkedId == R.id.rbTabSnacks) filterFoods("HEALTHY_SNACKS");
        });
    }

    private void filterFoods(String mealType) {
        List<FoodItem> filtered = new ArrayList<>();
        for (FoodItem item : allFoods) {
            if (item.getMealType().equalsIgnoreCase(mealType)) {
                filtered.add(item);
            }
        }
        adapter.setFoods(filtered);
    }

    @Override
    public void onMarkAsEaten(FoodItem food) {
        food.setEaten(true);
        totalCaloriesConsumed += food.getCalories();
        totalProtein += food.getProteinGrams();
        totalCarbs += food.getCarbsGrams();
        mealsCompleted++;

        updateNutritionSummary();
        adapter.notifyDataSetChanged();

        // Synchronize with Firebase
        SessionManager session = new SessionManager(this);
        String uid = session.getUserId();
        String today = FirebaseHelper.getInstance().getTodayDateString();

        FirebaseHelper.getInstance().getUserRootRef(uid).child("DailyActivity").child(today)
                .child("caloriesConsumed").setValue(totalCaloriesConsumed);

        Toast.makeText(this, "Logged " + food.getName() + " (+" + food.getCalories() + " kcal)", Toast.LENGTH_SHORT).show();
    }

    private void updateNutritionSummary() {
        String summary = String.format(Locale.getDefault(),
                "Today's Nutrition: %d kcal consumed • %dg Protein • %dg Carbs • %d meals logged",
                totalCaloriesConsumed, totalProtein, totalCarbs, mealsCompleted);
        tvNutritionSummary.setText(summary);
    }
}
