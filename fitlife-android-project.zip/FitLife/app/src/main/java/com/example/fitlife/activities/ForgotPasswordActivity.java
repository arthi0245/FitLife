package com.example.fitlife.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fitlife.R;
import com.example.fitlife.firebase.FirebaseHelper;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText etEmail;
    private Button btnReset;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        etEmail = findViewById(R.id.etResetEmail);
        btnReset = findViewById(R.id.btnResetPassword);
        progressBar = findViewById(R.id.progressBarReset);

        btnReset.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            if (TextUtils.isEmpty(email)) {
                etEmail.setError("Please enter your registered email");
                return;
            }

            progressBar.setVisibility(View.VISIBLE);
            btnReset.setEnabled(false);

            FirebaseHelper.getInstance().getAuth().sendPasswordResetEmail(email)
                    .addOnCompleteListener(task -> {
                        progressBar.setVisibility(View.GONE);
                        btnReset.setEnabled(true);

                        if (task.isSuccessful()) {
                            Toast.makeText(ForgotPasswordActivity.this,
                                    "Password reset link sent to your email!", Toast.LENGTH_LONG).show();
                            finish();
                        } else {
                            String err = task.getException() != null ? task.getException().getMessage() : "Failed to send reset email";
                            Toast.makeText(ForgotPasswordActivity.this, err, Toast.LENGTH_LONG).show();
                        }
                    });
        });
    }
}
