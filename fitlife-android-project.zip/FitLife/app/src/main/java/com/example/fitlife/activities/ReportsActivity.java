package com.example.fitlife.activities;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fitlife.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ReportsActivity extends AppCompatActivity {

    private LineChart chartSteps;
    private BarChart chartCalories;
    private PieChart chartActivities;
    private RadioGroup rgTimeRange;
    private TextView tvReportTotalSteps, tvReportTotalCals, tvReportTotalDist, tvReportTotalMins;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        initViews();
        setupListeners();
        loadReportsForRange("Weekly");
    }

    private void initViews() {
        chartSteps = findViewById(R.id.chartSteps);
        chartCalories = findViewById(R.id.chartCalories);
        chartActivities = findViewById(R.id.chartActivities);
        rgTimeRange = findViewById(R.id.rgTimeRange);

        tvReportTotalSteps = findViewById(R.id.tvReportTotalSteps);
        tvReportTotalCals = findViewById(R.id.tvReportTotalCals);
        tvReportTotalDist = findViewById(R.id.tvReportTotalDist);
        tvReportTotalMins = findViewById(R.id.tvReportTotalMins);

        findViewById(R.id.btnBackReports).setOnClickListener(v -> finish());
    }

    private void setupListeners() {
        rgTimeRange.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbDaily) {
                loadReportsForRange("Daily");
            } else if (checkedId == R.id.rbWeekly) {
                loadReportsForRange("Weekly");
            } else if (checkedId == R.id.rbMonthly) {
                loadReportsForRange("Monthly");
            }
        });
    }

    private void loadReportsForRange(String range) {
        if ("Daily".equals(range)) {
            tvReportTotalSteps.setText("7,850");
            tvReportTotalCals.setText("460 kcal");
            tvReportTotalDist.setText("5.9 km");
            tvReportTotalMins.setText("42 mins");
            setupStepsLineChart(new String[]{"6am", "9am", "12pm", "3pm", "6pm", "9pm"}, new float[]{400, 1800, 3200, 4800, 6900, 7850});
            setupCaloriesBarChart(new String[]{"6am", "9am", "12pm", "3pm", "6pm", "9pm"}, new float[]{30, 110, 180, 260, 380, 460});
        } else if ("Monthly".equals(range)) {
            tvReportTotalSteps.setText("234,500");
            tvReportTotalCals.setText("14,200 kcal");
            tvReportTotalDist.setText("178 km");
            tvReportTotalMins.setText("1,140 mins");
            setupStepsLineChart(new String[]{"W1", "W2", "W3", "W4"}, new float[]{54000, 61000, 58500, 61000});
            setupCaloriesBarChart(new String[]{"W1", "W2", "W3", "W4"}, new float[]{3300, 3700, 3500, 3700});
        } else { // Weekly default
            tvReportTotalSteps.setText("54,620");
            tvReportTotalCals.setText("3,280 kcal");
            tvReportTotalDist.setText("41.5 km");
            tvReportTotalMins.setText("265 mins");
            setupStepsLineChart(new String[]{"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"},
                    new float[]{6800, 8200, 7100, 9400, 7500, 10200, 5420});
            setupCaloriesBarChart(new String[]{"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"},
                    new float[]{410, 490, 420, 560, 450, 610, 340});
        }
        setupActivitiesPieChart();
    }

    private void setupStepsLineChart(String[] labels, float[] values) {
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < values.length; i++) {
            entries.add(new Entry(i, values[i]));
        }

        LineDataSet dataSet = new LineDataSet(entries, "Steps");
        dataSet.setColor(Color.parseColor("#10B981"));
        dataSet.setCircleColor(Color.parseColor("#059669"));
        dataSet.setLineWidth(2.5f);
        dataSet.setCircleRadius(4f);
        dataSet.setDrawValues(false);
        dataSet.setDrawFilled(true);
        dataSet.setFillColor(Color.parseColor("#D1FAE5"));

        LineData lineData = new LineData(dataSet);
        chartSteps.setData(lineData);
        chartSteps.getDescription().setEnabled(false);
        chartSteps.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        chartSteps.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
        chartSteps.getXAxis().setGranularity(1f);
        chartSteps.getAxisRight().setEnabled(false);
        chartSteps.animateX(600);
        chartSteps.invalidate();
    }

    private void setupCaloriesBarChart(String[] labels, float[] values) {
        List<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < values.length; i++) {
            entries.add(new BarEntry(i, values[i]));
        }

        BarDataSet dataSet = new BarDataSet(entries, "Calories Burned (kcal)");
        dataSet.setColor(Color.parseColor("#F97316"));
        dataSet.setValueTextColor(Color.parseColor("#0F172A"));
        dataSet.setValueTextSize(10f);

        BarData barData = new BarData(dataSet);
        chartCalories.setData(barData);
        chartCalories.getDescription().setEnabled(false);
        chartCalories.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        chartCalories.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
        chartCalories.getXAxis().setGranularity(1f);
        chartCalories.getAxisRight().setEnabled(false);
        chartCalories.animateY(600);
        chartCalories.invalidate();
    }

    private void setupActivitiesPieChart() {
        List<PieEntry> entries = new ArrayList<>();
        entries.add(new PieEntry(45f, "Walking"));
        entries.add(new PieEntry(25f, "Running"));
        entries.add(new PieEntry(20f, "Workouts"));
        entries.add(new PieEntry(10f, "Cycling"));

        PieDataSet dataSet = new PieDataSet(entries, "Activity Breakdown");
        dataSet.setColors(new int[]{
                Color.parseColor("#10B981"),
                Color.parseColor("#3B82F6"),
                Color.parseColor("#8B5CF6"),
                Color.parseColor("#F59E0B")
        });
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.WHITE);

        PieData pieData = new PieData(dataSet);
        chartActivities.setData(pieData);
        chartActivities.getDescription().setEnabled(false);
        chartActivities.setHoleRadius(45f);
        chartActivities.setTransparentCircleRadius(50f);
        chartActivities.animateXY(700, 700);
        chartActivities.invalidate();
    }
}
