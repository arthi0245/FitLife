package com.example.fitlife.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fitlife.R;
import com.example.fitlife.firebase.FirebaseHelper;
import com.example.fitlife.utils.SessionManager;

public class SettingsActivity extends AppCompatActivity {

    private Switch switchNotifications, switchDarkMode, switchDemoSensor;
    private TextView tvCurrentStepGoal, tvCurrentWaterGoal;
    private Button btnChangeStepGoal, btnChangeWaterGoal, btnEditProfile, btnLogout;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        sessionManager = new SessionManager(this);
        initViews();
        setupListeners();
    }

    private void initViews() {
        switchNotifications = findViewById(R.id.switchNotifications);
        switchDarkMode = findViewById(R.id.switchDarkMode);
        switchDemoSensor = findViewById(R.id.switchDemoSensor);
        tvCurrentStepGoal = findViewById(R.id.tvCurrentStepGoal);
        tvCurrentWaterGoal = findViewById(R.id.tvCurrentWaterGoal);

        btnChangeStepGoal = findViewById(R.id.btnChangeStepGoal);
        btnChangeWaterGoal = findViewById(R.id.btnChangeWaterGoal);
        btnEditProfile = findViewById(R.id.btnSettingsEditProfile);
        btnLogout = findViewById(R.id.btnSettingsLogout);

        findViewById(R.id.btnBackSettings).setOnClickListener(v -> finish());

        tvCurrentStepGoal.setText(sessionManager.getStepGoal() + " steps / day");
        tvCurrentWaterGoal.setText(sessionManager.getWaterGoal() + " glasses / day");

        switchDarkMode.setChecked(sessionManager.isDarkMode());
        switchDemoSensor.setChecked(sessionManager.isDemoSensorMode());
    }

    private void setupListeners() {
        btnEditProfile.setOnClickListener(v -> startActivity(new Intent(this, ProfileActivity.class)));

        btnChangeStepGoal.setOnClickListener(v -> {
            EditText et = new EditText(this);
            et.setHint("e.g. 10000");
            et.setText(String.valueOf(sessionManager.getStepGoal()));

            new AlertDialog.Builder(this)
                    .setTitle("Update Step Goal")
                    .setView(et)
                    .setPositiveButton("Save", (dialog, which) -> {
                        try {
                            int newGoal = Integer.parseInt(et.getText().toString().trim());
                            sessionManager.setStepGoal(newGoal);
                            tvCurrentStepGoal.setText(newGoal + " steps / day");
                            Toast.makeText(this, "Step goal updated!", Toast.LENGTH_SHORT).show();
                        } catch (Exception ignored) {}
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        btnChangeWaterGoal.setOnClickListener(v -> {
            EditText et = new EditText(this);
            et.setHint("e.g. 8");
            et.setText(String.valueOf(sessionManager.getWaterGoal()));

            new AlertDialog.Builder(this)
                    .setTitle("Update Water Goal")
                    .setView(et)
                    .setPositiveButton("Save", (dialog, which) -> {
                        try {
                            int newGoal = Integer.parseInt(et.getText().toString().trim());
                            sessionManager.setWaterGoal(newGoal);
                            tvCurrentWaterGoal.setText(newGoal + " glasses / day");
                            Toast.makeText(this, "Water goal updated!", Toast.LENGTH_SHORT).show();
                        } catch (Exception ignored) {}
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        switchDarkMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sessionManager.setDarkMode(isChecked);
            Toast.makeText(this, "Theme preference saved", Toast.LENGTH_SHORT).show();
        });

        switchDemoSensor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sessionManager.setDemoSensorMode(isChecked);
            Toast.makeText(this, "Sensor mode preference saved", Toast.LENGTH_SHORT).show();
        });

        btnLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Log Out")
                    .setMessage("Are you sure you want to log out of FitLife?")
                    .setPositiveButton("Log Out", (dialog, which) -> {
                        FirebaseHelper.getInstance().getAuth().signOut();
                        sessionManager.logout();
                        Intent intent = new Intent(this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }
}
