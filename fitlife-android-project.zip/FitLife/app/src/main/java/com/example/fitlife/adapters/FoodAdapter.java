package com.example.fitlife.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fitlife.R;
import com.example.fitlife.models.FoodItem;

import java.util.ArrayList;
import java.util.List;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.FoodViewHolder> {

    public interface OnFoodActionListener {
        void onMarkAsEaten(FoodItem food);
    }

    private List<FoodItem> foodList = new ArrayList<>();
    private final OnFoodActionListener listener;

    public FoodAdapter(OnFoodActionListener listener) {
        this.listener = listener;
    }

    public void setFoods(List<FoodItem> foods) {
        this.foodList = foods != null ? foods : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_food, parent, false);
        return new FoodViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodViewHolder holder, int position) {
        FoodItem food = foodList.get(position);
        holder.bind(food, listener);
    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    static class FoodViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvMacros, tvBenefits, tvServing, tvGoalTag;
        Button btnMarkEaten;

        public FoodViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvFoodName);
            tvMacros = itemView.findViewById(R.id.tvFoodMacros);
            tvBenefits = itemView.findViewById(R.id.tvFoodBenefits);
            tvServing = itemView.findViewById(R.id.tvFoodServing);
            tvGoalTag = itemView.findViewById(R.id.tvFoodGoalTag);
            btnMarkEaten = itemView.findViewById(R.id.btnMarkEaten);
        }

        public void bind(FoodItem food, OnFoodActionListener listener) {
            tvName.setText(food.getName());
            String macros = food.getCalories() + " kcal • " + food.getProteinGrams() + "g Protein • " + food.getCarbsGrams() + "g Carbs";
            tvMacros.setText(macros);
            tvBenefits.setText(food.getHealthBenefits());
            tvServing.setText("Serving: " + food.getServingSize());
            tvGoalTag.setText("Goal: " + food.getRecommendedFor());

            if (food.isEaten()) {
                btnMarkEaten.setText("✓ Eaten Today");
                btnMarkEaten.setEnabled(false);
                btnMarkEaten.setAlpha(0.6f);
            } else {
                btnMarkEaten.setText("+ Mark as Eaten");
                btnMarkEaten.setEnabled(true);
                btnMarkEaten.setAlpha(1.0f);
                btnMarkEaten.setOnClickListener(v -> {
                    if (listener != null) listener.onMarkAsEaten(food);
                });
            }
        }
    }
}
