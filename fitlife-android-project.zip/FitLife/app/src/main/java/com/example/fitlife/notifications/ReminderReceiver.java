package com.example.fitlife.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String ACTION_WATER_REMINDER = "com.example.fitlife.WATER_REMINDER";
    public static final String ACTION_WORKOUT_REMINDER = "com.example.fitlife.WORKOUT_REMINDER";
    public static final String ACTION_STEP_CHECK = "com.example.fitlife.STEP_CHECK";
    public static final String ACTION_SLEEP_REMINDER = "com.example.fitlife.SLEEP_REMINDER";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) return;

        switch (action) {
            case ACTION_WATER_REMINDER:
                NotificationHelper.showNotification(
                        context, 101, "💧 Time to Hydrate!",
                        "Drink a glass of water now to keep your metabolism energized.",
                        NotificationHelper.CHANNEL_REMINDERS
                );
                break;
            case ACTION_WORKOUT_REMINDER:
                NotificationHelper.showNotification(
                        context, 102, "💪 Today's Workout Awaits",
                        "Consistent effort leads to great results. Spend 20 minutes on your fitness routine today!",
                        NotificationHelper.CHANNEL_REMINDERS
                );
                break;
            case ACTION_STEP_CHECK:
                NotificationHelper.showNotification(
                        context, 103, "🏃 Check Your Daily Steps",
                        "A quick evening walk will help you hit today's step and calorie target!",
                        NotificationHelper.CHANNEL_REMINDERS
                );
                break;
            case ACTION_SLEEP_REMINDER:
                NotificationHelper.showNotification(
                        context, 104, "🌙 Wind Down for Bed",
                        "Aim for 7-8 hours of quality sleep tonight for optimal muscle recovery.",
                        NotificationHelper.CHANNEL_REMINDERS
                );
                break;
        }
    }
}
