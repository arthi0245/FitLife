package com.example.fitlife.models;

import java.io.Serializable;

public class Goal implements Serializable {
    private String id;
    private String userId;
    private String type; // Steps, Calories, Distance, Water, Weight, Workout
    private String title;
    private double currentProgress;
    private double target;
    private String unit; // steps, kcal, km, glasses, kg, mins
    private boolean completed;
    private long updatedAt;

    public Goal() {}

    public Goal(String id, String userId, String type, String title, double currentProgress, double target, String unit) {
        this.id = id;
        this.userId = userId;
        this.type = type;
        this.title = title;
        this.currentProgress = currentProgress;
        this.target = target;
        this.unit = unit;
        this.completed = currentProgress >= target;
        this.updatedAt = System.currentTimeMillis();
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public double getCurrentProgress() { return currentProgress; }
    public void setCurrentProgress(double currentProgress) {
        this.currentProgress = currentProgress;
        this.completed = this.currentProgress >= this.target;
    }

    public double getTarget() { return target; }
    public void setTarget(double target) {
        this.target = target;
        this.completed = this.currentProgress >= this.target;
    }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public int getPercentage() {
        if (target <= 0) return 0;
        return (int) Math.min(100, Math.round((currentProgress / target) * 100));
    }

    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
}
