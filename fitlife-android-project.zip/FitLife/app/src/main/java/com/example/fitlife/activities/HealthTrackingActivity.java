package com.example.fitlife.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fitlife.R;
import com.example.fitlife.firebase.FirebaseHelper;
import com.example.fitlife.models.HealthData;
import com.example.fitlife.utils.BMICalculator;
import com.example.fitlife.utils.SessionManager;

import java.util.Locale;

public class HealthTrackingActivity extends AppCompatActivity {

    private EditText etHealthWeight, etHealthHeight;
    private TextView tvWaterCount, tvWaterSuggestion, tvSleepValue, tvHealthBmi, tvHealthScore, tvGeneralSuggestion;
    private ImageButton btnAddWater, btnRemoveWater;
    private SeekBar seekSleep;
    private Button btnSaveHealth;

    private int waterGlasses = 5;
    private int waterGoal = 8;
    private double sleepHours = 7.0;
    private double weightKg = 70.0;
    private double heightCm = 175.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_tracking);

        initViews();
        setupListeners();
        updateHealthMetrics();
    }

    private void initViews() {
        etHealthWeight = findViewById(R.id.etHealthWeight);
        etHealthHeight = findViewById(R.id.etHealthHeight);
        tvWaterCount = findViewById(R.id.tvWaterCount);
        tvWaterSuggestion = findViewById(R.id.tvWaterSuggestion);
        tvSleepValue = findViewById(R.id.tvSleepValue);
        seekSleep = findViewById(R.id.seekSleep);
        tvHealthBmi = findViewById(R.id.tvHealthBmi);
        tvHealthScore = findViewById(R.id.tvHealthScore);
        tvGeneralSuggestion = findViewById(R.id.tvGeneralSuggestion);

        btnAddWater = findViewById(R.id.btnAddWater);
        btnRemoveWater = findViewById(R.id.btnRemoveWater);
        btnSaveHealth = findViewById(R.id.btnSaveHealth);

        findViewById(R.id.btnBackHealth).setOnClickListener(v -> finish());
    }

    private void setupListeners() {
        btnAddWater.setOnClickListener(v -> {
            waterGlasses++;
            updateHealthMetrics();
        });

        btnRemoveWater.setOnClickListener(v -> {
            if (waterGlasses > 0) waterGlasses--;
            updateHealthMetrics();
        });

        seekSleep.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sleepHours = 4.0 + (progress * 0.5); // 4 to 12 hrs
                tvSleepValue.setText(String.format(Locale.getDefault(), "%.1f hrs", sleepHours));
                updateHealthMetrics();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnSaveHealth.setOnClickListener(v -> saveHealthData());
    }

    private void updateHealthMetrics() {
        tvWaterCount.setText(String.format(Locale.getDefault(), "%d / %d glasses", waterGlasses, waterGoal));

        int remainingWater = Math.max(0, waterGoal - waterGlasses);
        if (remainingWater == 0) {
            tvWaterSuggestion.setText("🎉 Great job! You reached today's hydration target!");
        } else if (remainingWater <= 2) {
            tvWaterSuggestion.setText(String.format(Locale.getDefault(), "Almost there! You need approximately %d more glass%s to reach today's goal.",
                    remainingWater, remainingWater > 1 ? "es" : ""));
        } else {
            tvWaterSuggestion.setText(String.format(Locale.getDefault(), "You need %d more glasses of water today for optimal vitality.", remainingWater));
        }

        try {
            if (!etHealthWeight.getText().toString().isEmpty()) {
                weightKg = Double.parseDouble(etHealthWeight.getText().toString());
            }
            if (!etHealthHeight.getText().toString().isEmpty()) {
                heightCm = Double.parseDouble(etHealthHeight.getText().toString());
            }
        } catch (Exception ignored) {}

        double bmi = BMICalculator.calculateBMI(weightKg, heightCm);
        String bmiCategory = BMICalculator.getCategory(bmi);
        tvHealthBmi.setText(String.format(Locale.getDefault(), "BMI: %.1f • %s", bmi, bmiCategory));

        int score = 40;
        if (waterGlasses >= waterGoal) score += 30;
        else score += (int) ((waterGlasses / (double) waterGoal) * 30);

        if (sleepHours >= 7.0 && sleepHours <= 9.0) score += 30;
        else score += 15;

        tvHealthScore.setText(score + " / 100");
        tvGeneralSuggestion.setText(BMICalculator.getHealthMessage(bmi));
    }

    private void saveHealthData() {
        SessionManager session = new SessionManager(this);
        String uid = session.getUserId();
        String today = FirebaseHelper.getInstance().getTodayDateString();

        HealthData data = new HealthData(today, uid);
        data.setWeightKg(weightKg);
        data.setHeightCm(heightCm);
        data.setWaterGlasses(waterGlasses);
        data.setWaterGoal(waterGoal);
        data.setSleepHours(sleepHours);

        FirebaseHelper.getInstance().syncHealthData(uid, data, task -> {
            Toast.makeText(this, "Health metrics saved & synced!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
