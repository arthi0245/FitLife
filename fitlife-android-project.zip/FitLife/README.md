# FitLife - Advanced Android Fitness Tracker

FitLife is a complete, production-grade, real-time Android Fitness Tracker built using **Java**, **XML layouts**, **Material Design Components**, **Firebase**, and **MPAndroidChart**.

## Key Features

1. **Authentication & Session Management**
   - Splash screen, Email/Password Login, User Registration, Password Reset.
   - Session persistence via `SharedPreferences` (`SessionManager`).
   - Secure Firebase Authentication integration.

2. **Profile & Dynamic Biometrics**
   - Height, Weight, Age, Gender, Fitness Level, and Goals.
   - Real-time BMI calculator with categorized health insights.
   - Cloud synchronization to Firebase Realtime Database / Firestore.

3. **Real-Time Step Counter & Sensors**
   - Hardware sensor integration with `Sensor.TYPE_STEP_COUNTER` and `Sensor.TYPE_STEP_DETECTOR`.
   - Automatic fallback to intelligent Demo Simulation Mode when physical hardware sensors are not available in emulators.
   - Stride-based distance and dynamic calorie burn calculations.

4. **Activity Tracker**
   - Real-time stopwatch and timer for Walking, Running, Cycling, and Gym Workouts.
   - Live pause, resume, and stop-and-save capabilities.
   - Automatic activity logging to Firebase.

5. **Health & Recovery Tracking**
   - Visual water glass tracker with remaining glass suggestions.
   - Sleep duration tracker (hours) with rest quality indicators.
   - Dynamic Daily Vitality Index score (0–100).

6. **Goal Management**
   - Create, edit, and delete daily targets (Steps, Calories, Water, Distance, Workouts).
   - Milestone triggers at 50%, 75%, and 100%.
   - Full celebration dialogs and system notifications upon goal completion.

7. **Workout Library**
   - Pre-configured routines: HIIT, Strength, Cardio, Yoga, Stretching.
   - Active workout timer with real-time calorie burn updates.

8. **Fitness Reports & Analytics**
   - Powered by `MPAndroidChart`.
   - Line chart for step progression.
   - Bar chart for calorie burn.
   - Pie chart for activity breakdown.
   - Daily, Weekly, and Monthly filters.

9. **AI Fitness Assistant (Chatbot)**
   - Conversational AI coach analyzing real-time user metrics.
   - Live query answering on workouts, nutrition, and daily progress.
   - Backend powered by Google Gemini with rule-based heuristic fallback.

10. **Nutritional Guidance**
    - Meal categories: Breakfast, Lunch, Evening, Dinner, Healthy Snacks.
    - Calorie and macro breakdowns (Protein, Carbs).
    - Meal logging with real-time calorie intake synchronization.

---

## How to Open and Run in Android Studio

1. Extract `fitlife-android-project.zip` to your desired folder.
2. Open **Android Studio** (Flamingo, Giraffe, Hedgehog, Iguana, or newer).
3. Select **File > Open** and choose the extracted `FitLife` directory.
4. Allow Gradle to sync dependencies automatically.
5. (Optional) To connect your own Firebase project:
   - Go to [Firebase Console](https://console.firebase.google.com/).
   - Create an Android App with package name `com.example.fitlife`.
   - Download `google-services.json` and place it in the `app/` folder.
6. Click **Run > Run 'app'** or connect your physical Android device / launch an Android Emulator (API 26+).
